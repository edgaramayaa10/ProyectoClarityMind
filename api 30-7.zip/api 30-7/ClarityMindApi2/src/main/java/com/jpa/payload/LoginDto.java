package com.jpa.payload;

public class LoginDto {

}
