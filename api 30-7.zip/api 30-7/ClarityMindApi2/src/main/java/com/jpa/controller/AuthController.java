package com.jpa.controller;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import jakarta.mail.MessagingException;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.config.JwtUtils;
import com.jpa.entity.ERole;
import com.jpa.entity.Role;
import com.jpa.entity.User;
import com.jpa.entity.VerificationToken;
import com.jpa.payload.LoginRequest;
import com.jpa.payload.MessageResponse;
import com.jpa.payload.SignupRequest;
import com.jpa.payload.UserInfoResponse;
import com.jpa.repository.RoleRepository;
import com.jpa.repository.UserRepository;
import com.jpa.repository.VerificationTokenRepository;
import com.jpa.service.EmailService;
import com.jpa.service.UserDetailsImpl;



//for Angular Client (withCredentials)
//@CrossOrigin(origins = "http://localhost:8081", maxAge = 3600, allowCredentials="true")
@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/auth")
public class AuthController {
  @Autowired
  AuthenticationManager authenticationManager;

  @Autowired
  UserRepository userRepository;
  
  @Autowired
  private VerificationTokenRepository tokenRepository;

  @Autowired
  private EmailService emailService;

  @Autowired
  RoleRepository roleRepository;

  @Autowired
  PasswordEncoder encoder;

  @Autowired
  JwtUtils jwtUtils;

  @PostMapping("/signin")
  public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest) {

    Authentication authentication = authenticationManager
        .authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(), loginRequest.getPassword()));

    SecurityContextHolder.getContext().setAuthentication(authentication);

    UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

    ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(userDetails);

    List<String> roles = userDetails.getAuthorities().stream()
        .map(item -> item.getAuthority())
        .collect(Collectors.toList());

    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
        .body(new UserInfoResponse(userDetails.getId(),
                                   userDetails.getUsername(),
                                   userDetails.getEmail(),
                                   roles));
  }

  @PostMapping("/signup")
  public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
	  System.out.println("Received signupRequest: " + signUpRequest);
    if (userRepository.existsByUsername(signUpRequest.getUsername())) {
      return ResponseEntity.badRequest().body(new MessageResponse("Error: Username is already taken!"));
    }

    if (userRepository.existsByEmail(signUpRequest.getEmail())) {
      return ResponseEntity.badRequest().body(new MessageResponse("Error: Email is already in use!"));
    }

 // Create new user's account
    User user = new User(signUpRequest.getName(),
                         signUpRequest.getUsername(),
                         signUpRequest.getEmail(),
                         encoder.encode(signUpRequest.getPassword()));

    Set<String> strRoles = signUpRequest.getRole();
    Set<Role> roles = new HashSet<>();

    // Always assign ROLE_USER by default
    Role userRole = roleRepository.findByName(ERole.ROLE_USER)
            .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
    roles.add(userRole);

    if (strRoles != null) {
        strRoles.forEach(role -> {
            switch (role) {
                case "admin":
                    Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
                            .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                    roles.add(adminRole);
                    break;
                case "mod":
                    Role modRole = roleRepository.findByName(ERole.ROLE_MODERATOR)
                            .orElseThrow(() -> new RuntimeException("Error: Role is not found."));
                    roles.add(modRole);
                    break;
                // The default case for "user" is handled above, so it can be omitted or used to log an unexpected role
                default:
                    // Handle unknown role cases if necessary
                    break;
            }
        });
    }

    user.setRoles(roles);
    userRepository.save(user);
    
    // Generate verification token
    String token = UUID.randomUUID().toString();
    VerificationToken verificationToken = new VerificationToken();
    verificationToken.setToken(token);
    verificationToken.setUser(user);
    verificationToken.setExpiryDate(new Date(System.currentTimeMillis() + 86400000)); // 1 day expiry

    tokenRepository.save(verificationToken);

    // Send email
    String recipientAddress = user.getEmail();
    String subject = "Account Activation";
    String confirmationUrl = "http://localhost:8080/api/auth/confirm?token=" + token;
    String message = "<p>To activate your account, please click the following link: <a href=\"" + confirmationUrl + "\">" + confirmationUrl + "</a></p>";
    try {
        emailService.sendEmail(recipientAddress, subject, message);
    } catch (MessagingException e) {
        return ResponseEntity.status(500).body(new MessageResponse("Error: Unable to send email."));
    }

    return ResponseEntity.ok(new MessageResponse("User registered successfully! Please check your email to activate your account."));


   
}
  @GetMapping("/confirm")
  public ResponseEntity<?> confirmAccount(@RequestParam("token") String token) {
      VerificationToken verificationToken = tokenRepository.findByToken(token);

      if (verificationToken == null || verificationToken.getExpiryDate().before(new Date())) {
          return ResponseEntity.badRequest().body(new MessageResponse("Error: Invalid or expired token."));
      }

      User user = verificationToken.getUser();
      user.setEnabled(true); // Asume que tienes un campo 'enabled' en la entidad User
      userRepository.save(user);

      return ResponseEntity.ok(new MessageResponse("Account activated successfully."));
  }

  @PostMapping("/signout")
  public ResponseEntity<?> logoutUser() {
    ResponseCookie cookie = jwtUtils.getCleanJwtCookie();
    return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, cookie.toString())
        .body(new MessageResponse("You've been signed out!"));
  }
}
